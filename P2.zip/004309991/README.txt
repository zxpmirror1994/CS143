THIS IS PROJECT 2 FOR CS143 SPRING 2016.
THREE MODIFIED FILES INCLUDED:
1. basicOperators.scala
Implement generateIterator()
2. CS143Utils.scala
Implement getUdfFromExpressions() and apply()
3. DiskHashedRelation.scala
Implement insert(), closeInput(), getData() and apply()

TEAM INFO:
004309991

