CREATE TABLE Movie (
       id INTEGER, -- A movie must have an id
       title VARCHAR(100) NOT NULL, 
       year INTEGER,
       rating VARCHAR(10),
       company VARCHAR(50),
       PRIMARY KEY (id), -- Movie id is unique to each movie
       CHECK (id >= 0 AND year >= 0) -- Movie id and release year must be nonnegative
) ENGINE = INNODB;

CREATE TABLE Actor (
       id INTEGER, -- An actor must have an id
       last VARCHAR(20) NOT NULL,
       first VARCHAR(20) NOT NULL,
       sex VARCHAR(6),
       dob DATE,
       dod DATE,
       PRIMARY KEY (id), -- Actor id is unique to each actor
       CHECK (id >= 0) -- Actor id must be nonnegative
) ENGINE = INNODB;

CREATE TABLE Sales (
       mid INTEGER,
       ticketsSold INTEGER,
       totalIncome INTEGER,
       FOREIGN KEY (mid) REFERENCES Movie(id), -- mid references id of the movie table
       CHECK (ticketsSold >= 0) -- The number of tickets sold must be nonnegative
) ENGINE = INNODB;

CREATE TABLE Director (
       id INTEGER,
       last VARCHAR(20) NOT NULL,
       first VARCHAR(20) NOT NULL,
       dob DATE NOT NULL,
       dod DATE,
       PRIMARY KEY (id), -- Director id is unique to each director
       CHECK (id >= 0) -- Director id must be nonnegative
) ENGINE = INNODB;

CREATE TABLE MovieGenre (
       mid INTEGER,
       genre VARCHAR(20),
       FOREIGN KEY (mid) REFERENCES Movie(id) -- mid references id of the movie table
) ENGINE = INNODB;

CREATE TABLE MovieDirector (
       mid INTEGER,
       did INTEGER,
       FOREIGN KEY (mid) REFERENCES Movie(id), -- mid references id of the movie table
       FOREIGN KEY (did) REFERENCES Director(id) -- did references id of the director table
) ENGINE = INNODB;

CREATE TABLE MovieActor (
       mid INTEGER,
       aid INTEGER,
       role VARCHAR(50),
       FOREIGN KEY (mid) REFERENCES Movie(id), -- mid references id of the movie table
       FOREIGN KEY (aid) REFERENCES Actor(id) -- aid references id of the actor table
) ENGINE = INNODB;

CREATE TABLE MovieRating (
       mid INTEGER,
       imdb INTEGER,
       rot INTEGER,
       FOREIGN KEY (mid) REFERENCES Movie(id), -- mid references id of the movie table
       CHECK ((imdb >= 0 AND imdb <= 100) AND (rot >= 0 AND rot <= 100)) -- rating should be within the range from 0 to 100
) ENGINE = INNODB;

CREATE TABLE Review (
       name VARCHAR(20),
       time TIMESTAMP,
       mid INTEGER,
       rating INTEGER,
       comment VARCHAR(500),
       FOREIGN KEY (mid) REFERENCES Movie(id) -- mid references id of the movie table
) ENGINE = INNODB;

CREATE TABLE MaxPersonID (
       id INTEGER
) ENGINE = INNODB;

CREATE TABLE MaxMovieID (
       id INTEGER
) ENGINE = INNODB;
