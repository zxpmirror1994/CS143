<html>
<head>Movie Database</head>
<body>
<h1>Movie Database Query</h1>
  Type an SQL query in the following box:<br/><br/>
  Example:<tt>SELECT * FROM Actor WHERE id &gt; 500;</tt> <br/>

<!--Build the textarea that can accommodate 10*80 character-->
<p>
<form METHOD="GET" ACTION="query.php">
  <TEXTAREA name='query' ROWS=10 COLS=80><?php
       echo htmlspecialchars($_GET["query"]); /*Keep the user input after submission*/
    ?></TEXTAREA> <br/>
  <input type="submit" value="Submit">
</form>
</p>

<h2>Result:</h2>

<!--Build connection with the database-->
<?php
  $db_connection = mysql_connect("localhost", "cs143", "");
  if(!$db_connection) {
    $errmsg = mysql_error($db_connection);
    print "Connection failed: $errmsg <br/>";
    exit(1);
  } /*Check connection to the database*/
  mysql_select_db("CS143", $db_connection);
  $userQuery = $_GET["query"];
  $rs = mysql_query($userQuery, $db_connection);
?>

<!--Insert field(attribute) names into the result table-->
<?php
  if (mysql_num_fields($rs) > 0) {
    echo '<table border=1 cellspacing=1 cellpadding=2>
            <tr align="center">';
  } /*Construct the table frame*/
  $index0fFields=0;
  while ($indexOfFields < mysql_num_fields($rs)) {
    $fields = mysql_fetch_field($rs, $indexOfFields);
    echo '<td><b>' . $fields->name . '</b></td>';     
    $indexOfFields = $indexOfFields + 1;
  } /*Fill the field names*/
?>
</tr>

<!--Insert tuples into the result table-->
<?php
  while ($row = mysql_fetch_row($rs)) {
    $indexOfRows = 0;
    echo '<tr align="center">';
    while ($indexOfRows != count($row)) { 
      if (current($row) != NULL) {
        echo '<td>' . current($row) . '</td>';
      }
      else {
        echo '<td>N/A</td>';
      }
      next($row);
      $indexOfRows = $indexOfRows+1;
    }
      echo '</tr>';
      $indexOfFields = $indexOfFields + 1;
  }
if (mysql_num_fields($rs) > 0) {
   echo '</table>';
}
?>

<!--Disconnect with the database-->
<?php
   mysql_free_result($rs);
   mysql_close($db_connection);
?>
</body>
</html> 
