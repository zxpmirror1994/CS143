SELECT CONCAT (a.first, ' ', a.last) AS nameOfActors -- CONCAT to meet the requirement
FROM MovieActor AS ma, Movie AS m, Actor AS a -- Three table join
WHERE ma.mid = m.id AND ma.aid = a.id AND m.title = 'Die Another Day'; -- Return the names of all the actors in the movie 'Die Another Day'.

SELECT COUNT(DISTINCT ma1.aid) AS numOfActors
FROM MovieActor AS ma1, MovieActor AS ma2 -- Self join by renaming
WHERE ma1.aid = ma2.aid AND ma1.mid > ma2.mid; -- Return the count of all the actors who acted in multiple movies.

SELECT m.title AS titleOfMovies
FROM Movie AS m, Sales As s
WHERE m.id = s.mid AND s.ticketsSold >= 1000000; -- Return the title of movies that sell more than 1,000,000 tickets.

SELECT m.title AS titleOfMovies, m.year AS yearOfMovies
FROM Movie AS m, MovieRating As mr
WHERE m.id = mr.mid AND mr.imdb >= 90 AND mr.rot >= 90; -- Return the titles and the years of all the movies that have scores of at least 90 from both IMDb Rating and Rotten Tomatoes rating. 

SELECT AVG(mr.imdb) AS averageRating
FROM Director AS d, MovieRating AS mr, MovieDirector AS md
WHERE d.id = md.did AND mr.mid = md.mid AND d.first = 'Barry'; -- Return the average imdb ratings (available) of all movies by directors with first name 'Barry'.
