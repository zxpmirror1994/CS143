-- Insert tuple with duplicate Actor id
INSERT INTO Actor VALUES(120,'Zhang','Xiaopei','Male',19941125,\N); 
-- This will fail because 'id' is the primary key of the Actor table and I cannot insert another tuple with the same 'id' that has existed into the table.
-- ERROR 1062 (23000): Duplicate entry '120' for key 'PRIMARY'

-- Insert tuple with duplicate Director id 
INSERT INTO Director VALUES(37146,'Zhang','Xiaopei',19941125,\N); 
-- This will fail because 'id' is the primary key of the Director table and I cannot insert another tuple with the same 'id' that has existed into the table.
-- ERROR 1062 (23000): Duplicate entry '37146' for key 'PRIMARY'

-- Insert tuple with duplicate Movie id
INSERT INTO Movie VALUES(272,'Zootopia',2016,'PG','Disney'); 
-- This will fail because 'id' is the primary key of the Movie table and I cannot insert another tuple with the same 'id' that has existed into the table.
-- ERROR 1062 (23000): Duplicate entry '272' for key 'PRIMARY'

-- Insert tuple with nonexistent Movie id
INSERT INTO Sales VALUES(11,50000,100000);
-- This will fail because 'mid' is a foreign key referenced to 'id' in the Movie table, but tuple with 'id=11' is not in the Movie table. The Sales table cannot contain information on a movie that is not present in the Movie table. 
-- ERROR 1452 (23000): Cannot add or update a child row: a foreign key constraint fails (`TEST`.`Sales`, CONSTRAINT `Sales_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `Movie` (`id`))

-- Insert tuple with nonexistent Movie id
INSERT INTO MovieGenre VALUES(11,'Comedy');
-- This will fail because 'mid' is a foreign key referenced to 'id' in the Movie table, but tuple with 'id=11' is not in the Movie table. The MovieGenre table cannot contain information on a movie that is not present in the Movie table.
-- ERROR 1452 (23000): Cannot add or update a child row: a foreign key constraint fails (`TEST`.`MovieGenre`, CONSTRAINT `MovieGenre_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `Movie` (`id`))

-- Insert tuple with nonexistent Movie(Director) id
INSERT INTO MovieDirector VALUES(11,11111); 
-- This will fail because 'mid'('did') is a foreign key referenced to 'id' in the Movie(Director) table, but tuple with 'id=11'('id=11111') does not exist in the Movie(Director) table. The MovieDirector table cannot contain information on a movie(director) that is not present in the Movie(Director) table.
-- ERROR 1452 (23000): Cannot add or update a child row: a foreign key constraint fails (`TEST`.`MovieDirector`, CONSTRAINT `MovieDirector_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `Movie` (`id`))

-- Insert tuple with nonexistent Movie(Actor) id
INSERT INTO MovieActor VALUES(11,12222,'Wilde');
-- This will fail because 'mid'('aid') is a foreign key referenced to 'id' in the Movie(Actor) table, but tuple with 'id=11'('id=12222') does not exist in the Movie(Actor) table. The MovieActor table cannot contain information on a movie(actor) that is not present in the Movie(Actor) table.
-- ERROR 1452 (23000): Cannot add or update a child row: a foreign key constraint fails (`TEST`.`MovieActor`, CONSTRAINT `MovieActor_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `Movie` (`id`))

-- Insert tuple with nonexistent Movie id
INSERT INTO MovieRating VALUES(11,95,19);
-- This will fail because 'mid' is a foreign key referenced to 'id' in the Movie table, but tuple with 'id=11' does not exist in the Movie table. The MovieRating table cannot contain information on a movie that is not present in the Movie table.
-- ERROR 1452 (23000): Cannot add or update a child row: a foreign key constraint fails (`TEST`.`MovieRating`, CONSTRAINT `MovieRating_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `Movie` (`id`))

-- Insert tuple with nonexistent Movie id
INSERT INTO Review VALUES('Xiaopei',\N,11,\N,'it is fantastic.');
-- This will fail because 'mid' is a foreign key referenced to 'id' in the Movie table, but tuple with 'id=11' does not exist in the Movie table. The Review table cannot contain information on a movie that is not present in the Movie tabe.
-- ERROR 1452 (23000): Cannot add or update a child row: a foreign key constraint fails (`TEST`.`Review`, CONSTRAINT `Review_ibfk_1` FOREIGN KEY (`mid`) REFERENCES `Movie` (`id`))

-- Insert an actor with null names
INSERT INTO Actor VALUES(2,\N,\N,'Male',\N,\N);
-- This will fail because we set 'last' and 'first' to be not null
-- ERROR 1048 (23000): Column 'last' cannot be null


-- Below queries should have been failed if check is available:
INSERT INTO Actor VALUES(-1,'Zhang','Xiaopei','Male',19941125,\N); -- This will fail because 'id' must be a nonnegative integer
INSERT INTO Movie VALUES(-1,'Zootopia',-2016,'PG','Disney'); -- This will fail because 'id' and 'year' must be nonnegative integers
INSERT INTO Director VALUES(-5,'Zhang','Xiaopei',19941125,\N); -- This will fail because 'id' must be a nonnegative integer
INSERT INTO Sales VALUES(272,-20000,100000); -- This will fail because 'ticketsSold' must be nonnegative
INSERT INTO MovieRating VALUES(272,120,-3); -- This will fail because 'imdb' and 'rot' exceed their ranges

