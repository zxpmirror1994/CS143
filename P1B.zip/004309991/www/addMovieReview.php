<!DOCTYPE html>
<html>
<!-- Link the css file for appearance -->
<link rel="stylesheet" type="text/css" href="stylish.css">
<font color="black">
<head>
	<title>Comment Movies</title>
</head>
<h1>Comment Movies</h1>
<body bgcolor="#00cc99">

<?php
$db_connection=mysql_connect("localhost","cs143","");
mysql_select_db("CS143",$db_connection);
?>

<form method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>">
<fieldset>
<!-- Create a text blank for user to enter who made the comment. Its size should match with the attribute-->
<p><label class="field" for="commentator">Commentator: </label>
<input type="text" name="commentator" size="20" maxlength="20" value="<?php echo htmlspecialchars($_GET['commentator']);?>" placeholder="Ex: Xiaopei Zhang">
</p>

<p><label class="field" for="movie">Movie: </label>
<SELECT name="movie">
<?php
if ($_GET['ref']==1)
{
	/* If the movie is specified by ID. This is used for adding comments after searching */
	$db_movie_id=$_GET['movie'];
	$db_all_movie=mysql_query("SELECT id, title, year FROM Movie WHERE id=$db_movie_id;", $db_connection) or die(mysql_error());
	$result=mysql_fetch_array($db_all_movie);
	$movie_id=$result["id"];
	$movie_title=$result["title"];
	$movie_year=$result["year"];
	echo "<option value=$movie_id>$movie_title ($movie_year) </option>";
}
else 
{
	/* If no specified movies, just list all possible movies. This is used for standard comments addition. */
	$db_all_movie=mysql_query("SELECT id, title, year FROM Movie ORDER BY title ASC;", $db_connection) or die(mysql_error());
	while ($result=mysql_fetch_array($db_all_movie))
	{     
	      	$movie_id=$result["id"];
		$movie_title=$result["title"];
		$movie_year=$result["year"];
		echo "<option value=$movie_id>$movie_title ($movie_year) </option>";
	}
}
mysql_free_result($db_all_movie);
?>
</SELECT>
</p>
<!-- Create a selection bar for user to select the score of the movie -->
<p><label class="field" for="rating">Rating: </label>
<SELECT name="rating">
<OPTION value=5 SELECTED>5 (Very good)</OPTION>
<OPTION value=4>4 (Nice)</OPTION>
<OPTION value=3>3 (So-So)</OPTION>
<OPTION value=2>2 (Not interesting)</OPTION>
<OPTION value=1>1 (Disgusting)</OPTION>
</SELECT>
</p>
<!-- Create a textarea for user to enter the comment. Its size should match with the attribute -->
<p><label class="field" for="comment">Comment: </label>
<TEXTAREA name='comment' maxlength="500" ROWS=8 COLS=60 placeholder="Please comment here"><?php echo htmlspecialchars($_GET['comment']);?></TEXTAREA>
</p>

</fieldset>
<div style="padding:5px;"><input type="submit" value="Add"></div>

</form>

<?php
$db_commentator_name=trim($_GET['commentator']);
$db_movie_id=$_GET['movie'];
$db_movie_rating=$_GET['rating'];
$db_movie_comment=trim($_GET['comment']);
if ($db_commentator_name==""&&$db_movie_id==""&&$db_movie_rating==""&&$db_movie_comment=="") /* Initial state: If no input captured, tell the user to enter something */
{
	echo "Please fill in the form as indicated";
}
else if ($db_commentator_name=="") /* If no commentator name captured, tell the user to enter the commentator name */
{
	echo "Blank in \"Commentator\"";
}
else if ($db_movie_id=="") /* If no movie captured, tell the user to select a movie */
{
	echo "Blank in \"Movie\"";
}
else if ($db_movie_rating=="") /* If no score captured, tell the user to select a score */
{
	echo "Blank in \"Rating\"";
}
else if ($db_movie_comment=="") /* If no comment captured, tell the user to leave some comments */
{
	echo "Blank in \"Comment\"";
}
else
{
	if ($_GET['ref']!=1)
	{
		$db_commentator_name=mysql_escape_string($db_commentator_name);
		$db_movie_comment=mysql_escape_string($db_movie_comment);
		mysql_query("INSERT INTO Review VALUES ('$db_commentator_name',now(),'$db_movie_id','$db_movie_rating','$db_movie_comment');", $db_connection) or die(mysql_error());
		echo "Comment to movie(ID:$db_movie_id) saved successfully";
	}
}
/* End the connection to the database */
mysql_close($db_connection);
?>
</body>
</font>
</html>
