<!DOCTYPE html>
<html>
<!-- Link the css file for appearance -->
<link rel="stylesheet" type="text/css" href="stylish.css">
<font color="black">
<head>
	<title>Add Actor/Director</title>
</head>
<h1>Add Actor/Director</h1>
<body bgcolor="#00cc99">

<form method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>">
<fieldset>
<!-- Create two radios for user to choose between "Actor" and "Director" -->
<p><label class="field" for="type">Category: </label>
<input type="radio" name="type" value="Actor" checked>Actor
<input type="radio" name="type" value="Director">Director
</p>
<!-- Create a text blank for user to enter the first name. Its size should match with the attribute-->
<p><label class="field" for="first">First Name: </label>
<input type="text" name="first" size="20" maxlength="20" value="<?php echo htmlspecialchars($_GET['first']);?>" placeholder="Ex: Tom">
</p>
<!-- Create a text blank for user to enter the last name. Its size should match with the attribute-->
<p><label class="field" for="last">Last Name: </label> 
<input type="text" name="last" size="20" maxlength="20" value="<?php echo htmlspecialchars($_GET['last']);?>" placeholder="Ex: Hanks">
</p>
<!-- Create two radios for user to choose between "Female" and "Maler" -->
<p><label class="field" for="sex">Gender: </label>
<input type="radio" name="sex" value="female" checked>Female
<input type="radio" name="sex" value="male">Male
</p>
<!-- Create a text blank for user to enter the date of birth. Its size should match with the attribute. A standard form is written for reference-->
<p><label class="field" for="dob">Date of Birth: </label>
<input type="text" name="dob" size="15" maxlength="15" value="<?php echo htmlspecialchars($_GET['dob']);?>" placeholder="Ex: 2016-01-01">(YYYY-MM-DD)
</p>
<!-- Create a text blank for user to enter the date of death. Its size should match with the attribute. A standard form is written for reference-->
<p><label class="field" for="dod">Date of Death: </label>
<input type="text" name="dod" size="15" maxlength="15" value="<?php echo htmlspecialchars($_GET['dod']);?>" placeholder="Ex: 2016-01-01">(YYYY-MM-DD)<br>
<font color="white">(Keep blank if still alive)</font>
</p>
</fieldset>
<div style="padding:5px;"><input type="submit" value="Add"></div>
</form>

<?php 
/* Connect to the database */
$db_connection=mysql_connect("localhost","cs143","");
mysql_select_db("CS143",$db_connection);
/* Obtain all the inputs and deal with them */
$db_category=trim($_GET['type']);
$db_first_name=trim($_GET['first']);
$db_last_name=trim($_GET['last']);
$db_gender=trim($_GET['sex']);
$db_dob=trim($_GET['dob']);
$db_dod=trim($_GET['dod']);
$db_parsed_dob=date_parse($db_dob);
$db_parsed_dod=date_parse($db_dod); 

if ($db_first_name==""&&$db_last_name==""&&$db_dob==""&&$db_dod=="") /* Initial state: If no input captured, tell the user to enter something */

{
	echo "Please fill in the form as indicated";
}
else if ($db_first_name=="") /* If no first name captured, tell the user to enter the first name */
{
	echo "Blank in \"First Name\"";
}
else if ($db_last_name=="") /* If no last name captured, tell the user to enter the last name */
{
	echo "Blank in \"Last Name\"";
}
else if ($db_dob=="") /* If no date of birth captured, tell the user to enter the date of birth */
{
        echo "Blank in \"Date of Birth\"";
}
else if (!checkdate($db_parsed_dob["month"],$db_parsed_dob["day"], $db_parsed_dob["year"])) /* If the date pf birth entered by the user is an invalid date, tell the user to re-enter */ 
{
	echo "Invalid \"Date of Birth\"";
}
else if ($db_dod!="" && !checkdate($db_parsed_dod["month"],$db_parsed_dod["day"], $db_parsed_dod["year"])) /* If the date pf death entered by the user is an invalid date, tell the user to re-enter or leave it blank */ 
{
	echo "Invalid \"Date of Death\"";
}
else
{
        $db_first_name=mysql_escape_string($db_first_name);
        $db_last_name=mysql_escape_string($db_last_name);
	$db_max_id_query=mysql_query("SELECT id FROM MaxPersonID;", $db_connection) or die(mysql_error());
	$db_max_id_arr=mysql_fetch_array($db_max_id_query);
	/* new MaxPersonID */
	$db_max_id=$db_max_id_arr[0];
	$db_new_max_id=$db_max_id+1;
	/* If the user want to add an actor */
	if ($db_category=='Actor')
	{
           if ($db_dod=="")
	   {
	      $insert_query="INSERT INTO Actor VALUES('$db_max_id','$db_last_name','$db_first_name','$db_gender','$db_dob',NULL);";
           }
	   else
	   {
	      $insert_query="INSERT INTO Actor VALUES('$db_max_id','$db_last_name','$db_first_name','$db_gender','$db_dob','$db_dod');";
           }
        }
	/* If the user want to add a director */
        else if ($db_category=='Director')
        {
	   if ($db_dod=="")
	   {
	      $insert_query="INSERT INTO Director VALUES('$db_max_id','$db_last_name','$db_first_name','$db_dob',NULL);";	
           }
           else
	   {
	      $insert_query="INSERT INTO Director VALUES('$db_max_id','$db_last_name','$db_first_name','$db_dob','$db_dod');";
	   }
	}
	$db_insert=mysql_query($insert_query,$db_connection) or die(mysql_error());
	$db_update=mysql_query("UPDATE MaxPersonID SET id=$db_new_max_id;",$db_connection) or die(mysql_error());
        echo "Add ($db_category: $db_first_name $db_last_name) successfully. His/Her ID is $db_max_id";
}
mysql_free_result($db_insert);
mysql_free_result($db_update);
/* End the connection to the database */
mysql_close($db_connection);

?>

</body>
</font>
</html>
