<!DOCTYPE html>
<html>
<!-- Link the css file for appearance -->
<link rel="stylesheet" type="text/css" href="stylish.css">
<font color="black">
<head>
	<title>Display Actor Information</title>
</head>
<h1>Display Actor Information</h1>
<body bgcolor="#00cc99">

<?php
$db_connection=mysql_connect("localhost","cs143","");
mysql_select_db("CS143",$db_connection);
?>
<!-- Create a text blank for user to enter the keyword interests him/her-->
<form method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>">
<fieldset>
<p><label class="field" for="search">Keyword: </label>
<input type="text" name="search" size="20" maxlength="20" value="<?php echo htmlspecialchars($_GET['search']);?>" placeholder="Ex: Tom Hanks">
</p>
</fieldset>
<div style="padding:5px;"><input type="submit" value="Search"></div>

</form>

<?php
$db_actor_id=trim($_GET['id']);
if ($db_actor_id=="") /* If not matching actor_id or at the initial visit*/
{
	echo "No matching results! You can search for any actor!";
}
else
{
	/* Show the general information about the actor */
	echo "<h2>Actor Portfolio: </h2>";
	$db_actor_shown=mysql_query("SELECT last,first,sex,dob,dod FROM Actor WHERE id=$db_actor_id", $db_connection) or die(mysql_error());
	$result=mysql_fetch_array($db_actor_shown);
	$db_first_name=$result["first"];
	$db_last_name=$result["last"];
	$db_gender=$result["sex"];
	$db_dob=$result["dob"];
	$db_dod=$result["dod"];
	echo "Name: $db_first_name $db_last_name <br> Gender: $db_gender <br> Date of Birth: $db_dob <br>";
	if ($db_dod=="")
	{
		echo "Date of Death: N/A";
	}
	else
	{
		echo "Date of Death: $db_dod";
	}
	mysql_free_result($db_actor_shown);
	echo "<br>";
	/* Show the movies that the actor acted in, provide links to the movies */
	echo "<h2>Act in: </h2>";
	$db_act_in=mysql_query("SELECT MA.role,M.title,M.year,M.id FROM MovieActor AS MA, Movie AS M WHERE MA.mid=M.id AND MA.aid=$db_actor_id ORDER BY M.year DESC;", $db_connection) or die(mysql_error());
	while ($result=mysql_fetch_array($db_act_in))
	{
		$movie_id=$result["id"];
		$movie_role=$result["role"];
		$movie_title=$result["title"];
		$movie_year=$result["year"];
		echo "Role: \"$movie_role\" in <a href=\"./showMovie.php?id=$movie_id\" style=\"color:white;\">$movie_title ($movie_year)</a><br>";
	}
	echo "<br>";
	mysql_free_result($db_act_in);
}
/* End the connection to the database */
mysql_close($db_connection);

?>

<?php
/* Link this with the searching page */
$db_search=$_GET['search'];
if ($db_search!="")
{
	header("Location: ./searchInfo.php?search=$db_search");
	exit;
}
?>

</body>
</font>
</html>
