<!DOCTYPE html>
<html>
<!-- Link the css file for appearance -->
<link rel="stylesheet" type="text/css" href="stylish.css">
<font color="black">
<head>
	<title>Navigation</title>
</head>
<h1>Navigation Menu</h1>
<body bgcolor="#00cc99">
<h3>Adding-Original:</h3>
<ul>
	<li><a href="./addActorDirector.php" target="main" style="color:white">Add Actor/Director</a></li>
	<li><a href="./addMovie.php" target="main" style="color:white">Add Movie</a></li>
	<li><a href="./addMovieReview.php" target="main" style="color:white">Comment Movies</a></li>
	<li><a href="./addMovieActor.php" target="main" style="color:white">Add Actor With Movie</a></li>
	<li><a href="./addMovieDirector.php" target="main" style="color:white">Add Director With Movie</a></li>
</ul><br>
<h3>Browsing-Existed:</h3>
<ul>
	<li><a href="./showActor.php" target="main" style="color:white">Display Actor Information</a></li>
	<li><a href="./showMovie.php" target="main" style="color:white">Display Movie Information</a></li>
</ul><br>
<h3>Searching-Interested:</h3> 
<ul>
	<li><a href="./searchInfo.php" target="main" style="color:white">Search For What You Want</a></li>
</ul>

</body>
</font>
</html>
