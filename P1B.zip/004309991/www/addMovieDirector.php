<!DOCTYPE html>
<html>
<!-- Link the css file for appearance -->
<link rel="stylesheet" type="text/css" href="stylish.css">
<font color="black">
<head>
	<title>Add Director With Movie</title>
</head>
<h1>Add Director With Movie</h1>
<body bgcolor="#00cc99">
<!-- Connect to the database here. Because we need to show all movies/directors as options for user to select -->
<?php
$db_connection=mysql_connect("localhost","cs143","");
mysql_select_db("CS143",$db_connection);
?>

<form method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>">
<fieldset>
<!-- Create a selection bar for user to select the director. All the actors come from the Director table -->
<p><label class="field" for="director">Director: </label>
<SELECT name="director">
<?php
$db_all_director=mysql_query("SELECT id, first, last, dob FROM Director ORDER BY first ASC;", $db_connection) or die(mysql_error());
while ($result=mysql_fetch_array($db_all_director))
{
	$director_id=$result["id"];	
	$director_first_name=$result["first"];
	$director_last_name=$result["last"];
	$director_dob=$result["dob"];
	/* Each director serves as an option in the selection bar */
	echo "<option value=$director_id>$director_first_name $director_last_name ($director_dob) </option>";
}
mysql_free_result($db_all_director);
?>
</SELECT>
</p>
<!-- Create a selection bar for user to select the movie. All the movies come from the Movie table -->
<p><label class="field" for="movie">Movie: </label>
<SELECT name="movie">
<?php
$db_all_movie=mysql_query("SELECT id, title, year FROM Movie ORDER BY title ASC;", $db_connection) or die(mysql_error());
while ($result=mysql_fetch_array($db_all_movie))
{     
	$movie_id=$result["id"];
	$movie_title=$result["title"];
	$movie_year=$result["year"];
	/* Each movie serves as an option in the selection bar */
	echo "<option value=$movie_id>$movie_title ($movie_year) </option>";
}
mysql_free_result($db_all_movie);
?>
</SELECT>
</p>
</fieldset>
<div style="padding:5px;"><input type="submit" value="Add"></div>

</form>

<?php

$db_movie_id=$_GET['movie'];
$db_director_id=$_GET['director'];
if ($db_movie_id==""&&$db_director_id=="") /* Initial state: If no input captured, tell the user to enter something */
{
	echo "Please fill in the form as indicated";
}
else if ($db_movie_id=="")  /* If no movie captured, tell the user to select a movie */
{
	echo "Blank in \"Movie\"";
}
else if ($db_director_id=="") /* If no director captured, tell the user to select a director */
{
	echo "Blank in \"Director\"";
}
else
{
	/* If the movie-director relation has existed, do not add again */
	$if_existed=mysql_query("SELECT COUNT(*) FROM MovieDirector WHERE mid='$db_movie_id' AND did='$db_director_id';", $db_connection) or die(mysql_error());
	$times=mysql_fetch_array($if_existed);
	$times=$times[0];
	if ($times==0)
	{
		mysql_query("INSERT INTO MovieDirector VALUES ('$db_movie_id','$db_director_id');", $db_connection) or die(mysql_error());
		echo "Link movie (ID:$db_movie_id) and director (ID:$db_director_id) successfully";
	}
	else
	{
		echo "This relation has existed!";
	}
	mysql_free_result($if_existed);
}
/* End the connection to the database */
mysql_close($db_connection);
?>

</body>
</font>
</html>
