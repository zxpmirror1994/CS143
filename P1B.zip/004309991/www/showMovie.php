<!DOCTYPE html>
<html>
<!-- Link the css file for appearance -->
<link rel="stylesheet" type="text/css" href="stylish.css">
<font color="black">
<head>
	<title>Display Movie Information</title>
</head>
<h1>Display Movie Information</h1>
<body bgcolor="#00cc99">

<?php
$db_connection=mysql_connect("localhost","cs143","");
mysql_select_db("CS143",$db_connection);
?>

<form method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>">
<fieldset>
<!-- Create a text blank for user to enter the keyword interests him/her-->
<p><label class="field" for="search">Keyword: </label>
<input type="text" name="search" size="20" value="<?php echo htmlspecialchars($_GET['search']);?>" placeholder="Ex: Forrest Gump">
</p>
</fieldset>
<div style="padding:5px;"><input type="submit" value="Search"></div>

</form>

<?php
$db_movie_id=trim($_GET['id']);
if ($db_movie_id=="") /* If not matching actor_id or at the initial visit*/
{
	echo "No matching results! You can search for any movie!";
}
else
{
	/* Show the general information about the actor */
	echo "<h2>Movie Introduction: </h2>";
	$db_movie_shown=mysql_query("SELECT title,year,rating,company FROM Movie WHERE id=$db_movie_id", $db_connection) or die(mysql_error());
	$result=mysql_fetch_array($db_movie_shown);
	$movie_title=$result["title"];
	$movie_company=$result["company"];
	$movie_year=$result["year"];
	$movie_rating=$result["rating"];
	if ($movie_title!="")
	{
		echo "Title: $movie_title<br>";
	}
	else
	{
		echo "Title: N/A<br>";
	}
	if ($movie_company!="")
	{
		echo "Company: $movie_company<br>";
	}
	else
	{
		echo "Company: N/A<br>";
	}
	if ($movie_year!="")
	{
		echo "Release Year: $movie_year<br>";
	}
	else
	{
		echo "Release Year: N/A<br>";
	}
	if ($movie_rating!="")
	{
		echo "Rating: $movie_rating<br>";
	}
	else
	{
		echo "Rating: N/A<br>";
	}
	mysql_free_result($db_movie_shown);
	
	/* Show all directors with the movie. Seperate them by comma. */
	echo "Director(s): ";
	$db_movie_director=mysql_query("SELECT D.last,D.first FROM MovieDirector AS MD, Director AS D WHERE MD.mid=$db_movie_id AND MD.did=D.id;", $db_connection) or die(mysql_error());
	$director_record=mysql_num_rows($db_movie_director);
	if ($director_record==0)
	{
		echo "N/A<br>";
	}
	else
	{
		$flag=true;
		while ($result=mysql_fetch_array($db_movie_director))
		{
			$director_first_name=$result["first"];
			$director_last_name=$result["last"];
			if ($flag)
			{
				$t=false;
			}
			else
			{
				echo ", ";
			}
			echo "$director_first_name $director_last_name<br>";
		}
	}
	mysql_free_result($db_movie_director);

	/* Show all genres of the movie. Seperate them by comma. */
	echo "Genre(s): ";
	$db_movie_genre=mysql_query("SELECT genre FROM MovieGenre WHERE mid=$db_movie_id;", $db_connection) or die(mysql_error());
	$genre_record=mysql_num_rows($db_movie_genre);
	if ($genre_record==0)
	{  
		echo "N/A<br>";
	}
	else
	{
		$flag=true;
		while ($result=mysql_fetch_array($db_movie_genre))
		{
			$movie_genre=$result["genre"];
			if ($flag)
			{
				$flag=false;
			}
			else
			{
				echo ", ";
			}
			echo "$movie_genre";
		}
	}
	mysql_free_result($db_movie_genre);
	echo "<br>";
	
	/* Show all actors that acted in this movie, provide links to the actors */
	echo "<h2>Relevant Actor(s)/Actress(es): </h2>";
	$db_movie_actor=mysql_query("SELECT A.id,A.last,A.first,MA.role  FROM Actor AS A, MovieActor AS MA WHERE MA.mid=$db_movie_id AND MA.aid=A.id ORDER BY first ASC;") or die(mysql_error());
	while ($result=mysql_fetch_array($db_movie_actor))
	{
		$actor_id=$result["id"];
		$actor_first_name=$result["first"];
		$actor_last_name=$result["last"];
		$actor_movie_role=$result["role"];
		echo "<a href=\"./showActor.php?id=$actor_id\" style=\"color:white;\">$actor_first_name $actor_last_name</a> as \"$actor_movie_role\"<br>";
	}
	mysql_free_result($db_movie_actor);
	echo "<br>";
	
	/* Show the average score of the movie, as well as total number of scores. Also, provide a link for user to add rating/comment */
	echo "<h2>History Rating(s): </h2>";
	$db_movie_rating=mysql_query("SELECT COUNT(rating), SUM(rating) FROM Review WHERE mid=$db_movie_id;", $db_connection) or die(mysql_error());
	$result=mysql_fetch_row($db_movie_rating);
	if ($result[0]==0&&$result[1]==0)
	{
		echo "Average rating: N/A<br>";
		echo "<a href=\"addMovieReview.php?movie=$db_movie_id&ref=1\" style=\"color:white;\">Comment/Rate this movie!</a><br>";
	}
	else
	{
		$movie_num_rating=$result[0];
		$movie_avg_rating=$result[1]/$result[0];
		echo "Average rating: <font color=\"red\">$movie_avg_rating</font> (out of 5) by <font color=\"red\">$movie_num_rating</font> review(s)<br>";
		echo "<a href=\"addMovieReview.php?movie=$db_movie_id&ref=1\" style=\"color:white;\">Comment/Rate this movie!</a><br>";
	}
	mysql_free_result($db_movie_rating);
	echo "<br>";

	/* Show all comments of this movie, including the times, commentator names and what the comments are */
	echo "<h2>History Comment(s): </h2>";
	$db_movie_comment=mysql_query("SELECT time,name,rating,comment FROM Review WHERE mid=$db_movie_id ORDER BY time DESC", $db_connection) or die(mysql_error());
	$comment_index=1;
	while ($result=mysql_fetch_array($db_movie_comment))
	{
		echo "$comment_index. ";
		$comment_commentator=$result["name"];
		$comment_time=$result["time"];
		$comment_rating=$result["rating"];
		$comment_comment=$result["comment"];
		if ($comment_commentator==""&&$comment_comment=="")
		{
			echo "In $comment_time, a reviewer rated this movie <font color=\"red\">$comment_rating</font> (out of 5) but left no comments<br>";
		}
		else if ($comment_commentator=="")
		{
			echo "In $comment_time, a reviewer rated this movie <font color=\"red\">$comment_rating</font> (out of 5), saying: <br>\"$comment_comment\"<br>";
		}
		else if ($comment_comment=="")
		{
			echo "In $comment_time, $comment_commentator rated this movie <font color=\"red\">$comment_rating</font> (out of 5) but left no comments<br>";
		}
		else
		{
			echo "In $comment_time, $comment_commentator rated this movie <font color=\"red\">$comment_rating</font> (out of 5), saying: <br>\"$comment_comment\"<br>";
		}
		$comment_index=$comment_index+1;
	}
	echo "<br>";
	mysql_free_result($db_movie_comment);

}
/* End the connection to the database */
mysql_close($db_connection);
?>


<?php
/* Link this with the searching page */
$db_search=$_GET["search"];
if ($db_search!="")
{
	header("Location: ./searchInfo.php?search=$db_search");
	exit;
}
?>
</body>
</font>
</html>
