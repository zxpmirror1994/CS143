<!DOCTYPE html>
<html>
<!-- Link the css file for appearance -->
<link rel="stylesheet" type="text/css" href="stylish.css">
<font color="black">
<head>
	<title>Add Movie</title>
</head>
<h1>Add Movie</h1>
<body bgcolor="#00cc99">

<form method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>">
<fieldset>
<!-- Create a text blank for user to enter the movie title. Its size should match with the attribute-->
<p><label class="field" for="title">Title: </label>
<input type="text" name="title" size="25" maxlength="100" value="<?php echo htmlspecialchars($_GET['title']);?>" placeholder="Ex: Forrest Gump">
</p>
<!-- Create a text blank for user to enter the producer company. Its size should match with the attribute-->
<p><label class="field" for="company">Company: </label>
<input type="text" name="company" size="25" maxlength="50" value="<?php echo htmlspecialchars($_GET['company']);?>" placeholder="Ex: Universal">
</p>
<!-- Create a text blank for user to enter the release year. Its size should match with the attribute-->
<p><label class="field" for="year">Release Year: </label>
<input type="text" name="year" size="15" maxlength="10" value="<?php echo htmlspecialchars($_GET['year']);?>" placeholder="Ex: 2016">
</p>
<!-- Create a selection bar for user to select the rating of the movie -->
<p><label class="field" for="rating">MPAA Rating: </label>
<SELECT name="rating">
<OPTION SELECTED>G</OPTION>
<OPTION>NC-17</OPTION>
<OPTION>PG</OPTION>
<OPTION>PG-13</OPTION>
<OPTION>R</OPTION>
<OPTION>surrendere</OPTION>
</SELECT>
</p>
<!-- Create 19 checkboxes for user to select the genres of the movie -->
<p><label class="field" for="genre">Genre: </label>
<table style="width:40em;">
<tr>
<td><input type="checkbox" name="genre[]" value="Action">Action</td>
<td><input type="checkbox" name="genre[]" value="Adult">Adult</td>
<td><input type="checkbox" name="genre[]" value="Adventure">Adventure</td>
<td><input type="checkbox" name="genre[]" value="Animation">Animation</td>
</tr>

<tr>
<td><input type="checkbox" name="genre[]" value="Comedy">Comedy</td>
<td><input type="checkbox" name="genre[]" value="Crime">Crime</td>
<td><input type="checkbox" name="genre[]" value="Documentary">Documentary</td>
<td><input type="checkbox" name="genre[]" value="Drama">Drama</td>
</tr>

<tr>
<td><input type="checkbox" name="genre[]" value="Family">Family</td>
<td><input type="checkbox" name="genre[]" value="Fantasy">Fantasy</td>
<td><input type="checkbox" name="genre[]" value="Horror">Horror</td>
<td><input type="checkbox" name="genre[]" value="Musical">Musical</td>
</tr>

<tr>
<td><input type="checkbox" name="genre[]" value="Mystery">Mystery</td>
<td><input type="checkbox" name="genre[]" value="Romance">Romance</td>
<td><input type="checkbox" name="genre[]" value="Sci-Fi">Sci-Fi</td>
<td><input type="checkbox" name="genre[]" value="Short">Short</td>
</tr>

<tr>
<td><input type="checkbox" name="genre[]" value="Thriller">Thriller</td>
<td><input type="checkbox" name="genre[]" value="War">War</td>
<td><input type="checkbox" name="genre[]" value="Western">Western</td>
</tr>
</table>
<font color="white">(Select as many options as you want)</font>
</p>

</fieldset>
<div style="padding:5px;"><input type="submit" value="Add"></div>

</form>

<?php
/* Connect to the database */
$db_connection=mysql_connect("localhost","cs143","");
mysql_select_db("CS143",$db_connection);
/* Obtain all the inputs and deal with them */
$db_movie_title=trim($_GET['title']);
$db_movie_company=trim($_GET['company']);
$db_release_year=trim($_GET['year']);
$db_mpaa_rating=$_GET['rating'];
$db_movie_genre=$_GET['genre'];

if ($db_movie_title==""&&$db_movie_company==""&&$db_release_year=="") /* Initial state: If no input captured, tell the user to enter something */
{
	echo "Please fill in the form as indicated";
}
else if ($db_movie_title=="") /* If no movie title captured, tell the user to enter the movie title */
{
	echo "Blank in \"Title\"";
}
else if ($db_movie_company=="") /* If no movie company captured, tell the user to enter the movie company */
{
        echo "Blank in \"Company\"";
}
else if ($db_release_year=="") /* If no release year captured, tell the user to enter the release year */
{
        echo "Blank in \"Release Year\"";
}
else if ($db_release_year <= 0 || $db_release_year > 2016) /* If the user entered an invalid release year, tell the user to re-enter */
{
	echo "Invalid \"Release year\"";
}
else if (count($db_movie_genre)==0) /* If no movie genres checked, tell the user to check the movie genres */
{
	echo  "Blank in \"Genre(s)\"";
}
else
{
	$db_movie_title=mysql_escape_string($db_movie_title);
	$db_movie_company=mysql_escape_string($db_movie_company);
	$db_max_id_query=mysql_query("SELECT id FROM MaxMovieID;", $db_connection) or die(mysql_error());
	$db_max_id_arr=mysql_fetch_array($db_max_id_query);
	/* new MaxMovieID */
	$db_max_id=$db_max_id_arr[0];
	$db_new_max_id=$db_max_id+1;
	/* Adding tuple to Movie table must be before adding to MovieGenre table due to foreign key constraint */
	mysql_query("INSERT INTO Movie VALUES ('$db_max_id','$db_movie_title','$db_release_year','$db_mpaa_rating','$db_movie_company');",$db_connection) or die(mysql_error());
	/* For one movie, we allow multiple genres, and each (movie, genre) pair is a tuple in MovieGenre table */
	$index=0;
	while ($index<count($db_movie_genre))
	{
		$insert_temp=$db_movie_genre[$index];
		mysql_query("INSERT INTO MovieGenre VALUES ('$db_max_id','$insert_temp');", $db_connection) or die(mysql_error());
		$index=$index+1;
	}
	mysql_query("UPDATE MaxMovieID SET id=$db_new_max_id;", $db_connection) or die(mysql_error());
	echo "Add ($db_movie_title) successfully. Its ID is $db_max_id";
}
/* End the connection to the database */
mysql_close($db_connection);

?>

</body>
</font>
</html>
