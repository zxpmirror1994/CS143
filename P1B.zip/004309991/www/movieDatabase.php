<!DOCTYPE html>
<html>
<link rel="stylesheet" type="text/css" href="stylish.css">
<head>
	<title>Movie Database</title>
</head>
<FRAMESET COLS="25%, 75%" FRAMEBORDER="1" BORDER="5">
<FRAME name="dir" src="directory.php">
<FRAME name="main" src="addActorDirector.php">
</FRAMESET>
</html>
