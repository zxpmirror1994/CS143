<!DOCTYPE html>
<html>
<!-- Link the css file for appearance -->
<link rel="stylesheet" type="text/css" href="stylish.css">
<font color="black">
<head>
	<title>Search For What You Want</title>
</head>
<h1>Search For What You Want</h1>
<body bgcolor="#00cc99">

<form method="GET" action="<?php echo $_SERVER['PHP_SELF'];?>">
<fieldset>
<!-- Create a text blank for user to enter the keyword interests him/her-->
<p><label class="field" for="search">Keyword: </label>
<input type="text" name="search" size="20" value="<?php echo htmlspecialchars($_GET['search']);?>" placeholder="Ex: Tom Hanks">
</p>
</fieldset>
<div style="padding:5px;"><input type="submit" value="Search"></div>

</form>

<?php
$db_connection=mysql_connect("localhost","cs143","");
mysql_select_db("CS143",$db_connection);
$db_search=$_GET['search'];
$db_search=mysql_escape_string($db_search);
/* Can seperate keywords with explode() */
$db_delimited=explode(' ', $db_search);

if (trim($db_search)!="") /* If the input is captured */
{
	/* List all movies containing the keyword */ 
	echo "<h2>Relevant Movie(s): </h2>";
	$db_search_movie_query="SELECT id,title,year FROM Movie WHERE (title LIKE '%$db_delimited[0]%')";
	$part_index=1;
	while($part_index<count($db_delimited))
	{
		$db_append=$db_delimited[$part_index];
		/* Append this to existing query */
		$db_search_movie_query.="AND (title LIKE '%$db_append%')";
		$part_index=$part_index+1;
	}
	$db_search_movie_result=mysql_query($db_search_movie_query, $db_connection) or die(mysql_error());

	$movie_index=1;
	while ($result=mysql_fetch_array($db_search_movie_result))
	{
		$movie_id=$result["id"];
		$movie_title=$result["title"];
		$movie_year=$result["year"];
		/* Provide links to movies containing the keyword */ 
		echo "$movie_index. <a href=\"./showMovie.php?id=$movie_id\" style=\"color:white;\">$movie_title ($movie_year)</a><br>";
		$movie_index=$movie_index+1;
	}
	mysql_free_result($db_search_movie_result);
	
	echo "<br>";
	/* List all actors containing the keyword */ 
	echo "<h2>Relevant Actor(s): </h2>";
	$db_search_actor_query="SELECT id,last,first,dob FROM Actor WHERE (first LIKE '%$db_delimited[0]%' OR last LIKE '%$db_delimited[0]%')";
	$part_index=1;
	while($part_index<count($db_delimited))
	{
		$db_append=$db_delimited[$part_index];
		/* Append this to existing query */
		$db_search_actor_query.="AND (first LIKE '%$db_append%' OR last LIKE '%$db_append%')";
		$part_index=$part_index+1;
	}
	$db_search_actor_result=mysql_query($db_search_actor_query, $db_connection) or die(mysql_error());

	$actor_index=1;
	while ($result=mysql_fetch_array($db_search_actor_result))
	{
		$actor_id=$result["id"];
		$actor_first_name=$result["first"];
		$actor_last_name=$result["last"];
		$actor_dob=$result["dob"];
		/* Provide links to actors containing the keyword */ 
		echo "$actor_index. <a href=\"./showActor.php?id=$actor_id\" style=\"color:white;\">$actor_first_name $actor_last_name ($actor_dob)</a><br>";
		$actor_index=$actor_index+1;
	}
	mysql_free_result($db_search_actor_result);
}
else /* If not input is captured */
{
	echo "No matching results! You can search for any keyword!";
}
/* End the connection to the database */
mysql_close($db_connection);

?>

</body>
</font>
</html>
