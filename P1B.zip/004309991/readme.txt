Lab 1B is finished by Xiaopei Zhang, including files of:
www/:
1. addActorDirector.php
2. addMovie.php
3. addMovieActor.php
4. addMovieDirector,php
5. addMovieReview.php
6. directory.php
7. movieDatabase.php
8. searchInfo.php
9. showActor.php
10. showMovie.php
11. stylish.css

sql/:
12. create.sql
13. load.sql

testcase/:
14. t1.html
15. t2.html
16. t3.html
17. t4.html
18. t5.html

19. readme.txt
20. team.txt

The base php file is "movieDatabase.php". All the testcases have this as the base URL. It contains 2 frames, 1 for directory, 1 for major page. stylish.css is a CSS file that modifies the webpage appearance. My pages seem to work well under all fundamental requirements.
